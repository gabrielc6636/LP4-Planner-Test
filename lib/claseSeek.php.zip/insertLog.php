<?php 
include_once("DBManager.php");
?>

<?
class claseLog{ 

function set_log($corrida,$idTren,$heading,$coordinates,$ramal,$tren,$velocidad,$gps1,$gps2){ 

$con = new DBManager;
	    
		if($con->conectar()==true){
		
		//$query = "select ti.idTren from TrenItem ti where ti.nombre = '".$coordinates."'";
		//$result = @mysql_query($query);
		
		//	if (!$result){
		//	   echo 'Error get_log';
		//	}else{
		//		$idTren = mysql_fetch_array($result);
		//		//return $campo['fecha']." | ".$campo['ip'];
		//		//return $result;
		//	}
		//}
		
		//inserto ip
		$query_insert = "INSERT INTO TablaLog (idCorridaLog,idTren,coordinates,velocidad,heading,gps1,gps2,tren,ramal,fecha) 
		                 values('".$corrida."','".$idTren."','".$coordinates."','".$velocidad."','".$heading."','".$gps1."','".$gps2."','".$tren."','".$ramal."',CURRENT_TIMESTAMP)";

		
		@mysql_query($query_insert);
		//fin isnerto ip
		}


 
// Recogemos las la informaci�n de las variables enviadas desde el
// formulario por el usuario con el m�todo POST
 
//$corrida=$_POST['Corrida'];
//$idTren=$_POST['IdTren'];
//$heading=$_POST['Heading'];
//$coordinates=$_POST['Coordinates'];
//$ramal=$_POST['Ramal'];
//$tren=$_POST['Tren'];
//$velocidad=$_POST['Velocidad'];
//$gps1=$_POST['GPS1'];
//$gps2=$_POST['GPS2'];
 
 
 

 }
 
	function get_log(){
	   $con = new DBManager;
	   if($con->conectar()==true){
		
		
		$query = "select ti.idTren,ti.nombre,ti.descripcion,(CAST(tl.heading as DECIMAL))AS heading,tl.coordinates,(IF(ISNULL(r.nombre), 'TEST', r.nombre))AS ramal,tl.tren,CAST(SUBSTRING(tl.Velocidad,1,3) as DECIMAL) as velocidad,tl.gps1,tl.gps2 from TablaLog tl left join Ramales r on trim(r.idRamal) = trim(tl.ramal) inner join TrenItem ti on ti.idTren=tl.idTren inner join CorridaLog c on c.idCorridaLog = tl.idCorridaLog where c.idCorridaLog = (select MAX(idCorridaLog) from CorridaLog) order by r.idRamal asc";
		$result = @mysql_query($query);
		
			if (!$result){
			   echo 'Error get_log';
			}else{
				//$campo = mysql_fetch_array($result);
				//return $campo['fecha']." | ".$campo['ip'];
				return $result;
			}
		}
	}
	
	function get_log_ramal(){
	   $con = new DBManager;
	   if($con->conectar()==true){
		
		
		$query = "select ti.idTren,ti.nombre,ti.descripcion,(CAST(tl.heading as DECIMAL))AS heading,tl.coordinates,(IF(ISNULL(r.nombre), 'TEST', r.nombre))AS ramal,tl.tren,CAST(SUBSTRING(tl.Velocidad,1,3) as DECIMAL) as velocidad,tl.gps1,tl.gps2 from TablaLog tl left join Ramales r on trim(r.idRamal) = trim(tl.ramal) inner join TrenItem ti on ti.idTren=tl.idTren inner join CorridaLog c on c.idCorridaLog = tl.idCorridaLog where c.idCorridaLog = (select MAX(idCorridaLog) from CorridaLog) and tl.ramal=1 order by r.idRamal asc";
		$result = @mysql_query($query);
		
			if (!$result){
			   echo 'Error get_log';
			}else{
				//$campo = mysql_fetch_array($result);
				//return $campo['fecha']." | ".$campo['ip'];
				return $result;
			}
		}
	}
	
	function get_log1(){
	   $con = new DBManager;
	   if($con->conectar()==true){
		
		
		$query = "select ti.idTren,
				   ti.nombre,
				   ti.descripcion,
				   (CAST(tl.heading as DECIMAL))AS heading,
				   tl.coordinates,
				   (IF(ISNULL(r.nombre), 'TEST', r.nombre))AS ramal,
				   tl.tren,
				   CAST(SUBSTRING(tl.Velocidad,1,3) as DECIMAL) as velocidad,
				   tl.gps1,
				   tl.gps2, 
				   g.nombre,
				   tl.idCorridaLog , 
				   c.fecha
			from TablaLog tl 
				left join Ramales r on r.idRamal = tl.ramal 
				inner join TrenItem ti on ti.idTren=tl.idTren
				inner join CorridaLog c on c.idCorridaLog = tl.idCorridaLog
				inner join GrupoTren g on g.idGrupo = ti.idGrupo
			where c.idCorridaLog = (select MAX(idCorridaLog) from CorridaLog) and 
			((CAST(tl.heading as DECIMAL))>0 and CAST(SUBSTRING(tl.Velocidad,1,3) as DECIMAL)>0) order by tl.ramal asc,CAST(trim(tl.idTren) as DECIMAL) asc";
		$result = @mysql_query($query);
		
			if (!$result){
			   echo 'Error get_log';
			}else{
				//$campo = mysql_fetch_array($result);
				//return $campo['fecha']." | ".$campo['ip'];
				return $result;
			}
		}
	}
	
	function get_vmax(){
	   $con = new DBManager;
	   if($con->conectar()==true){
		
		
		$query = "    select ti.idTren,ti.nombre,ti.descripcion,(CAST(tl.heading as DECIMAL))AS heading,tl.coordinates,(IF(ISNULL(r.nombre), 'TEST', r.nombre))AS ramal,tl.tren,CAST(SUBSTRING(tl.Velocidad,1,3) as DECIMAL) as velocidad,     c.fecha as gps1,
       tl.gps2,c.fecha from TablaLog tl left join Ramales r on trim(r.idRamal) = trim(tl.ramal) inner join TrenItem ti on ti.idTren=tl.idTren inner join CorridaLog c on c.idCorridaLog = tl.idCorridaLog 
    where CAST(SUBSTRING(tl.Velocidad,1,3) as DECIMAL)>80 order by 8 desc,r.idRamal asc,tl.heading desc";
		$result = @mysql_query($query);
		
			if (!$result){
			   echo 'Error get_log';
			}else{
				//$campo = mysql_fetch_array($result);
				//return $campo['fecha']." | ".$campo['ip'];
				return $result;
			}
		}
	}
	
	function get_log_tren($idTren){
	   $con = new DBManager;
	   if($con->conectar()==true){
		
		
		$query = "select ti.idTren,ti.nombre,ti.descripcion,(CAST(tl.heading as DECIMAL))AS heading,tl.coordinates,(IF(ISNULL(r.nombre), 'TEST', r.nombre))AS ramal,tl.tren,tl.velocidad,tl.gps1,tl.gps2 
			from TablaLog tl left join Ramales r on trim(r.idRamal) = trim(tl.ramal) inner join TrenItem ti on tl.idTren=ti.idTren where ti.idTren = '".$idTren."' order by tl.idCorridaLog";
		$result = @mysql_query($query);
		
			if (!$result){
			   echo 'Error get_log';
			}else{
				
				return $result;
			}
		}
	}
	
	function get_estacion_contigua($idEstacion){
	   $con = new DBManager;
	   if($con->conectar()==true){
		/*
		$query = "select re.idRamales as ramal,re.idPos as pos
               from Ramales_Estaciones re 
               inner join Estaciones e on re.idEstacion = e.idEstaciones
               where e.codigoTBA ='".$idEstacion."'";
		
		$result = @mysql_query($query);
		
		$campo = mysql_fetch_array($result);
		//echo $campo['idCorridaLog'];
		
		$query = "select e.nombre,e.coordenadas,e.codigoTBA,re.idPos
               from Ramales_Estaciones re 
               inner join Estaciones e on re.idEstacion = e.idEstaciones
               where re.idPos in ((".$campo['pos']."-1),".$campo['pos'].",(".$campo['pos']."+1)) and re.idRamales = ".$campo['ramal']." order by re.idPos";
			*/
		
		$query = "select e.nombre,e.coordenadas,e.codigoTBA
				from Estaciones e 
				where e.codigoTBA in (".$idEstacion." ";
		
		$result = @mysql_query($query);
		
			if (!$result){
			   echo 'Error get_log';
			}else{
				
				return $result;
			}
		}
	}
	
	function get_estacion($idEstacion){
	   $con = new DBManager;
	   if($con->conectar()==true){
			
		/*$query = "select tbl.idTren as idTren,he.idTren as nTren,
		he.horario,
        CAST(he.horario as TIME) as hora,
        CAST( '18:00' as TIME) as horaActual,
        TIMEDIFF(CAST(he.horario as TIME),CAST( '18:00' as TIME)) as diferencia,
        TIME_TO_SEC(TIMEDIFF(CAST(he.horario as TIME),CAST('18:00' as TIME))) as timeOnSeconds,
        ti.descripcion,
        gt.nombre,
        cl.idCorridaLog,
        cl.fecha,tbl.coordinates,tbl.velocidad,
        (select he1.idEstacion
            from Horarios_Estaciones he1
            where he1.idTren= he.idTren  
            and TIME_TO_SEC(TIMEDIFF(CAST(he1.horario as TIME),CAST(he.horario as TIME))) > 0 
            order by he1.horario asc 
            limit 1) as POST,
        (select e.coordenadas
            from Horarios_Estaciones he1
            inner join Estaciones e on e.codigoTBA = he1.idEstacion
            where he1.idTren= he.idTren  
            and TIME_TO_SEC(TIMEDIFF(CAST(he1.horario as TIME),CAST(he.horario as TIME))) > 0 
            order by he1.horario asc 
            limit 1) as POSTPOS,
        he.idEstacion,
        e.coordenadas,
        (select e.nombre
            from Estaciones e1 where e1.codigoTBA = e.codigoTBA
            ) as nombreEST,
        (select he2.idEstacion
            from Horarios_Estaciones he2
            where he2.idTren= he.idTren
            and TIME_TO_SEC(TIMEDIFF(CAST(he2.horario as TIME),CAST(he.horario as TIME))) < 0
            order by he2.horario desc 
            limit 1) as ANT,
        (select e.coordenadas
            from Horarios_Estaciones he2
            inner join Estaciones e on e.codigoTBA = he2.idEstacion
            where he2.idTren= he.idTren
            and TIME_TO_SEC(TIMEDIFF(CAST(he2.horario as TIME),CAST(he.horario as TIME))) < 0
            order by he2.horario desc 
            limit 1) as ANTPOS,
        (select he3.idEstacion from Horarios_Estaciones he3 
            where he3.idTren = he.idTren 
            order by he3.horario desc limit 1) as FIN,
        (select e.nombre
            from Horarios_Estaciones he2
            inner join Estaciones e on e.codigoTBA = he2.idEstacion
            where he2.idTren= he.idTren
            order by he2.horario desc limit 1) as FINEST
            ,(IF(he.idTren%2=0, 'DESC', 'ASC'))AS sentido
        from Horarios_Estaciones he 
        inner join Estaciones e on e.codigoTBA=he.idEstacion
        inner join TablaLog tbl on tbl.tren = he.idTren
        inner join CorridaLog cl on cl.idCorridaLog = tbl.idCorridaLog
        inner join TrenItem ti on tbl.idTren=ti.idTren
        inner join GrupoTren gt on gt.idGrupo = ti.idGrupo      
        where e.codigoTBA='".$idEstacion."'
        and tbl.idCorridaLog = (select MAX(idCorridaLog) from CorridaLog)
        and TIME_TO_SEC(TIMEDIFF(CAST(he.horario as TIME),CAST('18:00' as TIME))) between -1800 AND 1800
        order by he.idTren";*/
		
		$query = "select  tbl.idTren as idTren,
        he.idTren as nTren,
        CAST(he.horario as TIME) as horario,
        CAST( '18:00' as TIME) as horaActual,
        TIMEDIFF(CAST(he.horario as TIME),CAST( '18:00' as TIME)) as diferencia,
        TIME_TO_SEC(TIMEDIFF(CAST(he.horario as TIME),CAST('18:00' as TIME))) as timeOnSeconds,
        gt.nombre,
        tbl.velocidad,
        (select he1.idEstacion
            from Horarios_Estaciones he1
            where he1.idTren= he.idTren  
            and TIME_TO_SEC(TIMEDIFF(CAST(he1.horario as TIME),CAST(he.horario as TIME))) > 0 
            order by he1.horario asc 
            limit 1) as POST,
        
        he.idEstacion,
        e.nombre as nombreEST,
        e.coordenadas,
        (select he2.idEstacion
            from Horarios_Estaciones he2
            where he2.idTren= he.idTren
            and TIME_TO_SEC(TIMEDIFF(CAST(he2.horario as TIME),CAST(he.horario as TIME))) < 0
            order by he2.horario desc 
            limit 1) as ANT,
            t.cFin as FIN, 
            t.estFin as FINEST,
            t.sentido, 
            getMostrar(he.idTren,he.horario,
                       TIME_TO_SEC(TIMEDIFF(CAST(he.horario as TIME),CAST('18:00' as TIME))), 
                       tbl.coordinates,
                       he.idEstacion) as Mostrar,
            CalcularDistancia(e.coordenadas,CONCAT(SUBSTRING_INDEX(coordinates , ',', 1 ),',',SUBSTRING_INDEX(SUBSTRING_INDEX( coordinates , ',', 2 ),',',-1))) as distancia
        from Horarios_Estaciones he 
        inner join Estaciones e on e.codigoTBA=he.idEstacion
        inner join TablaLog tbl on tbl.tren = he.idTren
        inner join TrenItem ti on tbl.idTren=ti.idTren
        inner join GrupoTren gt on gt.idGrupo = ti.idGrupo
        inner join Trenes t on t.idTren = he.idTren
        where e.codigoTBA= '".$idEstacion."'
        and tbl.idCorridaLog = getCorrida()
        and TIME_TO_SEC(TIMEDIFF(CAST(he.horario as TIME),CAST('18:00' as TIME))) between -1800 AND 1800
        order by he.idTren";
		
		
		$result = @mysql_query($query);
		
			if (!$result){
			   echo 'Error get_log';
			}else{
				
				return $result;
			}
		}
	}
	
	function get_log_tren1($idTren){
	   $con = new DBManager;
	   if($con->conectar()==true){
		
		
		$query = "select ti.idTren,
		                 ti.nombre,
						 ti.descripcion,
						 (CAST(tl.heading as DECIMAL))AS heading,
						 tl.coordinates,
						 (IF(ISNULL(r.nombre), 'TEST', r.nombre))AS ramal,
						 tl.tren,
						 tl.velocidad,
						 tl.gps1,
						 tl.gps2 
			from TablaLog tl left join Ramales r on trim(r.idRamal) = trim(tl.ramal) inner join TrenItem ti on tl.idTren=ti.idTren where ti.idTren = '".$idTren."' AND tl.idCorridaLog = (select idCorridaLog from CorridaLog order by idCorridaLog desc LIMIT 1)";
		$result = @mysql_query($query);
		
			if (!$result){
			   echo 'Error get_log';
			}else{
				
				return $result;
			}
		}
	}
	
	function get_corrida(){
	   $con = new DBManager;
	   if($con->conectar()==true){
		
		$query = "select idCorridaLog from CorridaLog order by idCorridaLog desc LIMIT 1";
		$result = @mysql_query($query);
		
			if (!$result){
			   echo 'Error get_tiempo';
			}else{
				$campo = mysql_fetch_array($result);
				return $campo['idCorridaLog'];
			}
		}
	}
	
	function get_corrida_ins(){
	   $con = new DBManager;
	   if($con->conectar()==true){
		
		$query = "INSERT INTO CorridaLog(fecha,idLog) select CURRENT_TIMESTAMP,MAX(id) from log";
		$result = @mysql_query($query);
		/*echo $result;
			if (!$result){
			   echo 'Error get_tiempo';
			}else{*/
				$query = "select MAX(idCorridaLog) as idCorridaLog from CorridaLog";
				$result = @mysql_query($query);
		/*
					if (!$result){
					   echo 'Error get_tiempo';
					}else{*/
						$campo = mysql_fetch_array($result);
						echo $campo['idCorridaLog'];/*
					}
				
			}*/
		}
	}
	
	function get_estaciones(){
	   $con = new DBManager;
	   if($con->conectar()==true){
		
		$query = "select codigoTBA,nombre from Estaciones order by 2 asc";
		$result = @mysql_query($query);
		
			if (!$result){
			   echo 'Error get_estaciones';
			}else{
				return $result;
			}
		}
	}
	
	function get_ramales(){
	   $con = new DBManager;
	   if($con->conectar()==true){
		
		$query = "select idRamal,nombre from Ramales";
		$result = @mysql_query($query);
		
			if (!$result){
			   echo 'Error get_ramales';
			}else{
				return $result;
			}
		}
	}
	
	function get_estacion_ramal($idRamal){
	   $con = new DBManager;
	   if($con->conectar()==true){
		
		$query = "select e.nombre,e.coordenadas,e.codigoTBA
               from Ramales_Estaciones re 
               inner join Estaciones e on re.idEstacion = e.idEstaciones
               where re.idRamales ='".$idRamal."' order by re.idPos";
		
		$result = @mysql_query($query);
		
			if (!$result){
			   echo 'Error get_log';
			}else{
				
				return $result;
			}
		}
	}
 
 }
?>